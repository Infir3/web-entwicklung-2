#!/usr/bin/env bash

# bootstrap.sh für die Veranstaltung Web-Entwicklung II für das WiSe 2017/2018

# Paketlisten aktualisieren
sudo apt-get update

# Benötigte Pakete installieren
sudo apt-get install -y gksu curl python-software-properties figlet git

# Install Google Chrome Browser
mkdir /home/vagrant/download
wget -q https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb -P /home/vagrant/download
sudo apt install -y /home/vagrant/download/google-chrome-stable_current_amd64.deb
rm -f -r /home/vagrant/download

# Install Visual Studio Code
wget -q https://go.microsoft.com/fwlink/?LinkID=760868 -O code.deb
sudo dpkg -i code.deb
rm -f code.deb

# Installation NodeJs
curl -sL https://deb.nodesource.com/setup_8.x | sudo -E bash -
sudo apt-get install -y nodejs

# Installation Typescript
sudo npm install -g typescript

# MongoDB Installation
sudo apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv 0C49F3730359A14518585931BC711F9BA15703C6
echo "deb [ arch=amd64,arm64 ] http://repo.mongodb.org/apt/ubuntu xenial/mongodb-org/3.4 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-3.4.list
sudo apt-get update
sudo apt-get install -y --allow-unauthenticated mongodb-org=3.4.2
sudo service mongod start
sudo systemctl enable mongod

## Startverknüpfungen auf Desktop anlegen
# Chrome
sudo  cp -p /home/vagrant/provision/desktop/Chrome.desktop /home/vagrant/Schreibtisch/Chrome.desktop
sudo  chmod +x /home/vagrant/Schreibtisch/Chrome.desktop 
sudo  chown vagrant:vagrant /home/vagrant/Schreibtisch/Chrome.desktop

# Visual Studio Code
sudo  cp /home/vagrant/provision/desktop/Code.desktop /home/vagrant/Schreibtisch/Code.desktop
sudo  chmod +x /home/vagrant/Schreibtisch/Code.desktop
sudo  chown vagrant:vagrant /home/vagrant/Schreibtisch/Code.desktop

# Konfigurationsordner löschen
sudo rm -r /home/vagrant/provision

# Automount Config
# Step 1: Add the vboxsf Module to the initram, so the guest knows how to handle vboxsf during startup
echo "vboxsf" | sudo tee -a /etc/initramfs-tools/modules
# Step 2: Build the new initramfs 
update-initramfs -u
# Step 3: Insert the shared folder into the /etc/fstab file so it is mounted during startup 
echo "vagrant /vagrant vboxsf rw,uid=1000,gid=1000 0 0" | sudo tee -a /etc/fstab 

# Done Message
figlet Done. Have Fun!
echo "Rebooting VM..."
sudo reboot