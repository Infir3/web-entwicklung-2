var express = require("express");
var myParser = require("body-parser");
var app = express();

app.use(myParser.urlencoded({extended:true}));
app.post("/postExample", function(request,response){
  console.log("Got a Request");
  var outHTML = "<html><head><title>TEST</title></head><body><h1>Parameter:</h1><br/><ul>";
  for(var attributename in request.body){
    outHTML += "<li><b>"+attributename+"</b>: "+request.body[attributename]+"</li>";
    console.log("Attribute name: "+attributename+": "+request.body[attributename]);
  }
  outHTML += "</ul></body></html>";
  response.send(outHTML);
});

app.listen(8080);
